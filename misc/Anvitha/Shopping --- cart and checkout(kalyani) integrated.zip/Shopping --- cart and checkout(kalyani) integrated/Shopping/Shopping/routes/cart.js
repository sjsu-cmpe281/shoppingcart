var cart = [];

var mongo = require("./mongo");
var mongoURL = "mongodb://localhost:27017/db_bag";
var coll;
var json_responses;
var output = [];

mongo.connect(mongoURL, function(){
	console.log('Connected to mongo at: ' + mongoURL);
	coll = mongo.collection('bags');
	
coll.find({},{image: 1, item_code: 1,type: 1,color: 1, gender: 1, price: 1, style: 1, _id: 0}).toArray(function(err,data){
	if(data)
	{
	json_responses = {"data":data};
	
	}else {
		console.log("No data found")
		
	}
	});
});



exports.addCart = function(req,res){
	
	item_code = req.param("item_code");
	
	console.log("item select is :"+item_code);
	
	cart.push(item_code);
	
	console.log("items in cart are: ")
	console.log(cart);
	
	output = cart;
	
	console.log("output of output");
	console.log(output);
	
} //end of addCart


exports.shoppingCart = function(req,res){
	
	var price = 0;
	var quantity = 0;
	var shoppingcart = [];
	
	for(p in output)
	{
		for(i in json_responses.data)
		{
			if(json_responses.data[i].item_code == cart[p])
			{
				shoppingcart.push(json_responses.data[i]);
			}
		}
	}

	
	for(a in shoppingcart)
	{
		shoppingcart[a]['quantity'] = 1;
	}
	
	for(i in shoppingcart)
	{
		price = Number(price) + Number(shoppingcart[i].price) ;
	}
	
	for(i in shoppingcart)
	{
		quantity = Number(quantity) + 1;
	}
	
	console.log("content for cart");
	console.log(shoppingcart);
	
	res.render('shoppingcart',{values:shoppingcart,price:price,quantity:quantity});
	
}

