exports.checkout = function(req, res){
  res.render('checkout');
};

