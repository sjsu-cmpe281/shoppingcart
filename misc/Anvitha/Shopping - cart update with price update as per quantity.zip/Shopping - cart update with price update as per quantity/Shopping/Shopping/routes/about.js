
exports.about = function(req, res){
  res.render('about', { title: 'About us' });
};