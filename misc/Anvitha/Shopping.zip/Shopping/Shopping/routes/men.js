
var mongo = require("./mongo");
var mongoURL = "mongodb://localhost:27017/db_bag";
var coll;
var json_responses;

console.log("reached men.js 1");

exports.allMen = function(req,res){


	console.log("reached men.js");
	
	mongo.connect(mongoURL, function(){
		console.log('Connected to mongo at: ' + mongoURL);
		coll = mongo.collection('bags');

	
	
	coll.find({gender: "men"},{image: 1, item_code: 1,type: 1,color: 1, gender: 1, price: 1, style: 1, _id: 0}).toArray(function(err,data){
		if(data)
		{
		console.log("print to check");
		console.log(data);
		json_responses = {"data":data};
		}else {
			console.log("No data found")
			
		}//else
		
	}); //find
	
	});
	
	res.render("men",{values:json_responses});
	
}