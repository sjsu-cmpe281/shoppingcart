//loading the 'men' angularJS module
var men = angular.module('men', []);
console.log("in angular cart")
//defining the men controller
men.controller('men', function($scope) {
	console.log("in angular cart - 1")
	$scope.addCart = function(data) {
		$scope.itemcode = data;
		console.log("button in angular: "+$scope.itemcode);
					
	};
})
