/**
 * New node file
 */

exports.addCart = function(req,res){
	
	item_code = req.param("item_code");
	
	console.log("item select is :"+item_code)
	
} //end of addCart